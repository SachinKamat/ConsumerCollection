package com.royalmail.StepDefinition;

import com.royalmail.Helpers.PageInstance;
import com.royalmail.Helpers.SeleniumTests;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import com.royalmail.Helpers.FileManipulation;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.*;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.royalmail.Helpers.FileManipulation.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class MyStepdefs extends PageInstance {
    private Response response;
    private ValidatableResponse json;
    private RequestSpecification request;

    private SeleniumTests seleniumTests=new SeleniumTests();;
    @Before()
    public void beforeScenario(Scenario scenario) {
         PageInstance.scenario =scenario;
    }

    @Given("^I read the barcode from the TestDataSheet$")
    public void iReadTheBarcodeFromTheTestDataSheet() throws IOException, InvalidFormatException {
        Boolean isValidBarcode = ValidateBarcode();
        Assert.assertEquals(true, isValidBarcode);
        Boolean isValidUID = ValidateUID();
        Assert.assertEquals(true, isValidUID);
    }

    @And("^I process the barcode in BIG Queue via WINSCP$")
    public void iProcessTheBarcodeInBIGQueueViaWINSCP() throws IOException, InterruptedException {
        Boolean isCSVCreatedSuccess = createCSV();
        Assert.assertEquals(true, isCSVCreatedSuccess);
        Boolean isCSVFileProcessedSuccess = processCSV();
        Assert.assertEquals(true, isCSVFileProcessedSuccess);
    }

    @When("^COSS file is successfully processed from the BIG Queue$")
    public void csvFileIsSuccessfullyProcessedFromTheBIGQueue() throws IOException, ParseException, InvalidFormatException {
//        Boolean isLogFileValidated = readAndValidateLog();
//        Assert.assertEquals(true,isLogFileValidated);
        Boolean isBarcodeUpdatedInJson = createJsonFile();

    }

    @Then("^I validate the preadvice generation of Barcode in EPS$")
    public void iValidateTheeventGenerationOfBarcodeInEPS(Map<String, String> responseFields, String Barcode) {
        response = given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded").when().get("http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + Barcode + "/details");
        json = response.then().statusCode(200);
        for (Map.Entry<String, String> field : responseFields.entrySet()) {
            System.out.println("Key " + field.getKey() + " value " + field.getValue());
            if (StringUtils.isNumeric(field.getValue())) {
                json.body(field.getKey(), equalTo(Integer.parseInt(field.getValue())));
            } else {
                json.body(field.getKey(), equalTo(field.getValue()));
            }
        }
    }

    public Boolean ValidateBarcode() throws IOException, InvalidFormatException {
        try {
            BARCODE = FileManipulation.readFile(0);
            RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + BARCODE + "/details";
            RequestSpecification httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
            Response response = httpRequest.get();
            int statusCode = response.getStatusCode();
            if (statusCode == 404) {
                return true;
            } else {
                while (statusCode != 404) {
                    removeRow(0);
                    BARCODE = FileManipulation.readFile(0);
                    RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + BARCODE + "/details";
                    httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
                    response = httpRequest.get();
                    statusCode = response.getStatusCode();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private Boolean ValidateUID() {
        try {
            UID = FileManipulation.readFile(1);
            RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + UID + "/details";
            RequestSpecification httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
            Response response = httpRequest.get();
            int statusCode = response.getStatusCode();
            if (statusCode == 404) {
                return true;
            } else {
                while (statusCode != 404) {
                    removeRow(1);
                    UID = FileManipulation.readFile(1);
                    RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + UID + "/details";
                    httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
                    response = httpRequest.get();
                    statusCode = response.getStatusCode();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Then("^I validate the event generation for the barcode in EPS$")
    public void iValidateTheEventGenerationForTheBarcodeInEPS(Map<String, String> responseFields) throws IOException, ParseException {
        response = given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded").when().get("http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + BARCODE + "/details");
        json = response.then().statusCode(200);
        for (Map.Entry<String, String> field : responseFields.entrySet()) {
            ArrayList<Map<String, ?>> jsonAsArrayList = json.extract()
                    .jsonPath().get(field.getKey());
            Optional<Map<String, ?>> filtered = jsonAsArrayList.stream()
                    .filter(m -> m.get("eventCode").equals(field.getValue()))
                    .findFirst();
            updateJsonFile(BARCODE, Event);
            Assert.assertTrue("Event generation is failed in EPS", filtered.isPresent());
        }
    }

    @Given("^I read the barcode from the Json Test Data$")
    public void iReadTheBarcodeFromTheJsonTestData() throws IOException, ParseException {
        BARCODE = getBarcodeFromJSON();
        System.out.println("Barcode "+BARCODE);
    }

    @And("^I wait for the scan to be performed on the barcode$")
    public void iWaitForTheScanToBePerformedOnTheBarcode() throws InterruptedException {
        Thread.sleep(12000);
    }

    @And("^I check for the scans performed on the barcode$")
    public void iCheckForTheScansPerformedOnTheBarcode() {
        Event=getEventFromJSON();
    }

    @When("^I Update and perform the scans on the barcode$")
    public void iUpdateAndPerformTheScansOnTheBarcode() {
        Boolean isScanPerformed=false;
        if(Event.equalsIgnoreCase("EVDAC")){
            isScanPerformed=PerformScan("EVGPD");
            Event="EVGPD";
        }else if(Event.equalsIgnoreCase("EVGPD")){
            isScanPerformed=PerformScan("EVKNA");
            Event="EVKNA";
        }else if(Event.equalsIgnoreCase("EVKNA")){
            isScanPerformed=PerformScan("EVNCE");
            Event="EVNCE";
        }else if(Event.equalsIgnoreCase("EVNCE")){
            isScanPerformed=PerformScan("EVKSP");
            Event="EVKSP";
        }
        Assert.assertEquals(true, isScanPerformed);
    }

    @Then("^I validate the event generation for the barcode in EPS for the scans performed$")
    public void iValidateTheEventGenerationForTheBarcodeInEPSForTheScansPerformed() throws IOException, ParseException {
        HashMap<String,String>MapToValidate=new HashMap<String,String>();
        MapToValidate.put("mailPieces.events",Event);
        iValidateTheEventGenerationForTheBarcodeInEPS(MapToValidate);
        iValidateTheEventGenerationForTheBarcodeInTAPI(MapToValidate);
    }

    @And("^I validate the event details for the Barcode in EPS$")
    public void iValidateTheEventDetailsForTheBarcodeInEPS(Map<String, String> responseFields) {
        response = given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded").when().get("http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + responseFields.get("mailPieces.mailPieceId") + "/details");
        json = response.then().statusCode(200);
        for (Map.Entry<String, String> field : responseFields.entrySet()) {
            System.out.println("Key " + field.getKey() + " value " + field.getValue());
            if (StringUtils.isNumeric(field.getValue())) {
                json.body(field.getKey(), equalTo(Integer.parseInt(field.getValue())));
            } else {
                json.body(field.getKey(), equalTo(field.getValue()));
            }
        }
    }

    @Given("^I read and assign the variables from the TestDataSheet to generate the coss file for preadvice$")
    public void iReadAndAssignTheVariablesFromTheTestDataSheetToGenerateTheCossFileForPreadvice() throws IOException, InvalidFormatException {

        Boolean isValidBarcode = ValidateBarcode();
        Assert.assertEquals(true, isValidBarcode);
        Boolean isValidUID = ValidateUID();
        Assert.assertEquals(true, isValidUID);

    }

    @Given("^I read and assign and process the preadvice from the TestDataSheet$")
    public void iReadAndAssignAndProcessThePreadviceFromTheTestDataSheet() throws IOException, InterruptedException {
        Boolean isPreadviceFileProcessed=readAndProcess("MultiplePreAdviceTestData.xlsx");
    }

    private Boolean readAndProcess(String fileName) throws IOException, InterruptedException {
        HashMap<String,String>getMap= new HashMap<String,String>();
        File src=new File(fileName);
        FileInputStream fis=new FileInputStream(src);
        XSSFWorkbook srcBook= new XSSFWorkbook(fis);
        XSSFSheet sourceSheet = srcBook.getSheetAt(0);
        DataFormatter formatter = new DataFormatter();
        XSSFRow sourceRow = null;
        for(int i=1;i<=sourceSheet.getLastRowNum();i++) {
            sourceRow = sourceSheet.getRow(i);
            getMap.put("BARCODE",sourceRow.getCell(0).getStringCellValue().trim());
            getMap.put("UID",sourceRow.getCell(1).getStringCellValue().trim());
            getMap.put("EMAIL",sourceRow.getCell(2).getStringCellValue().trim());
            getMap.put("MOBILE",formatter.formatCellValue(sourceRow.getCell(3)).trim());
            getMap.put("PRODUCT",sourceRow.getCell(4).getStringCellValue().trim());
            getMap.put("WIRENUMBER",sourceRow.getCell(5).getStringCellValue().trim());
            getMap.put("CUSTOMERACCOUNTNUMBER",formatter.formatCellValue(sourceRow.getCell(6)).trim());
            getMap.put("CONTRACTNUMBER",formatter.formatCellValue(sourceRow.getCell(7)).trim());
            getMap.put("POSTINGLOCATIONNUMBER",formatter.formatCellValue(sourceRow.getCell(8)).trim());
            getMap.put("FILETYPE",sourceRow.getCell(9).getStringCellValue().trim());
            getMap.put("LOCATIONID",formatter.formatCellValue(sourceRow.getCell(10)).trim());
            getMap.put("SOURCEPO",sourceRow.getCell(11).getStringCellValue().trim());
            getMap.put("SOURCEAddress",sourceRow.getCell(12).getStringCellValue().trim());
            getMap.put("SOURCEPOSTOWN",sourceRow.getCell(13).getStringCellValue().trim());
            getMap.put("DESTINATIONPO",formatter.formatCellValue(sourceRow.getCell(14)).trim());
            getMap.put("DESTINATIONADDRESS",formatter.formatCellValue(sourceRow.getCell(15)).trim());
            getMap.put("DESTINATIONPOSTTOWN",sourceRow.getCell(16).getStringCellValue().trim());
            getMap.put("BUILDINGNUMBER",formatter.formatCellValue(sourceRow.getCell(17)).trim());
            getMap.put("SMSID",formatter.formatCellValue(sourceRow.getCell(18)).trim());
            getMap.put("EMAILID",formatter.formatCellValue(sourceRow.getCell(19)).trim());
            System.out.println("getMap "+getMap);
            if(ValidateBarcode(getMap.get("BARCODE")) && ValidateUID(getMap.get("UID"))){
                createCSVfromSheet(getMap);
                processCSV();
             }else {
                System.out.println("Barcode or UID Already Processed "+getMap.get("BARCODE")+" : "+getMap.get("UID"));
            }
        }
        return true;
    }

    private static void createCSVfromSheet(HashMap<String, String> Map) throws FileNotFoundException {
        DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter PreAdvice_Date = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
        String BARCODE=Map.get("BARCODE");
        String UID=Map.get("UID");
        String EMAIL=Map.get("EMAIL");
        String MOBILE=Map.get("MOBILE");
        String PRODUCT=Map.get("PRODUCT");
        String WIRENUMBER = Map.get("WIRENUMBER");
        String CUSTOMERACCOUNTNUMBER = Map.get("CUSTOMERACCOUNTNUMBER");
        String CONTRACTNUMBER=Map.get("CONTRACTNUMBER");
        String POSTINGLOCATIONNUMBER=Map.get("POSTINGLOCATIONNUMBER");
        String FILETYPE=Map.get("FILETYPE");
        String LOCATIONID=Map.get("LOCATIONID");

        String SOURCEPO=Map.get("SOURCEPO");
        String SOURCEAddress=Map.get("SOURCEAddress");
        String SOURCEPOSTOWN= Map.get("SOURCEPOSTOWN");

        String DESTINATIONPO=Map.get("DESTINATIONPO");
        String DESTINATIONADDRESS=Map.get("DESTINATIONADDRESS");
        String DESTINATIONPOSTTOWN=Map.get("DESTINATIONPOSTTOWN");
        String BUILDINGNUMBER = Map.get("BUILDINGNUMBER");

        String SMSID=Map.get("SMSID");
        String EMAILID=Map.get("EMAILID");
        File csvOutputFile = new File("COSS"+WIRENUMBER+"_PreAdvice3_"+ ZonedDateTime.now().format(PreAdvice_Date).replaceAll("\\.","").replaceAll(":","")+".csv");
        List<String[]> dataLines = new ArrayList<>();
        dataLines.add(new String[]
                { "\"00\"","\"03\"","\""+FILETYPE+"\"","\""+CUSTOMERACCOUNTNUMBER+"\"","\"MULTIPLE\"","\"1\"","\"\"","\"\"","\"\"","\"LIVE\"","\""+ ZonedDateTime.now().format(FORMATTER)+"+00:00\"","\""+WIRENUMBER+"\"","\"\"","\"09\"" });
        dataLines.add(new String[]
                { "\"01\"","\"03\"","\"HEARTBEAT\"","\""+SOURCEAddress+"\"","\"\"","\"\"","\"\"","\"\"","\""+SOURCEPOSTOWN+"\"","\""+SOURCEPO+"\"","\"PHASE 3 F POSTER\"","\"123456789012\"","\"\"","\"\"","\"\"","\"royalmail.support@neopost.co.uk\"","\""+LOCATIONID+"\"","\""+POSTINGLOCATIONNUMBER+"\"" });
        dataLines.add(new String[]
                { "\"02\"","\"03\"","\"\"","\""+PRODUCT+"\"","\"\"","\"\"","\"\"","\"RoyalMAil\"","\"\"","\"\"","\"500\"","\"1\"","\"\"","\"RoyalMail\"","\""+BUILDINGNUMBER+"\"","\""+DESTINATIONADDRESS+"\"","\"\"","\""+DESTINATIONPOSTTOWN+"\"","\""+DESTINATIONPO+"\"","\"Inflight_TESTDATA\"","\"5\"","\"\"","\"\"","\"\"","\"GB\"","\"\"","\""+UID+"\"","\"1000\"","\"1\"","\"\"","\"4\"","\"\"","\"3\"","\"\"","\"\"","\"\"","\"\"","\""+BARCODE+"\"","\"1\"","\""+ZonedDateTime.now().format(DATE)+"\"","\""+ZonedDateTime.now().format(DATE)+"\"","\"\"","\"\"","\"GBR\"","\""+CONTRACTNUMBER+"\"","\"RoyalMail\"","\"0\"","\"\"","\"\"" });
        dataLines.add(new String[]
                { "\"03\"","\"03\"","\""+UID+"\"","\""+SMSID+"\"","\""+MOBILE+"\"" });
        dataLines.add(new String[]
                { "\"03\"","\"03\"","\""+UID+"\"","\""+EMAILID+"\"","\""+EMAIL+"\"" });
        dataLines.add(new String[]
                { "\"09\"","\"03\"","\"13\"" });
        try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
            dataLines.stream()
                    .map(FileManipulation::convertToCSV)
                    .forEach(pw::println);
        }
    }

    @Given("^I read and assign and process the Scans from the TestDataSheet$")
    public void iReadAndAssignAndProcessTheScansFromTheTestDataSheet() throws IOException, InterruptedException {
        processScansfromSheet("MultiplePreAdviceTestData.xlsx");
    }
    private static void processScansfromSheet(String fileName) throws IOException, InterruptedException {
        HashMap<String,String>getMap= new HashMap<String,String>();
        File src=new File(fileName);
        FileInputStream fis=new FileInputStream(src);
        XSSFWorkbook srcBook= new XSSFWorkbook(fis);
        XSSFSheet sourceSheet = srcBook.getSheetAt(1);
        XSSFRow sourceRow = null;
        DataFormatter formatter = new DataFormatter();
        XSSFRow FirstRow =sourceSheet.getRow(0);
        int rowNum=0;
        DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MM/d/yy");
        for(int i=0;i<FirstRow.getLastCellNum();i++){
            System.out.println("Date Value "+formatter.formatCellValue(FirstRow.getCell(i)) + " equals "+ZonedDateTime.now().format(DATE));
            if(formatter.formatCellValue(FirstRow.getCell(i)).equals(ZonedDateTime.now().format(DATE))){
                rowNum=i;
                break;
            }
        }
        for(int i=1;i<=sourceSheet.getLastRowNum();i++) {
            sourceRow = sourceSheet.getRow(i);
           try {
               if (sourceRow.getCell(rowNum).getStringCellValue() != null) {
                   getMap.put("BARCODE", sourceRow.getCell(0).getStringCellValue());
                   getMap.put("EVENT", sourceRow.getCell(rowNum).getStringCellValue());
                   getMap.put("LOCATION", formatter.formatCellValue(sourceRow.getCell(1)));
               }
           }catch (Exception e){
               e.printStackTrace();
           }
            PerformScan(getMap);
            Thread.sleep(10000);
        }
    }
    @Given("^I read and assign data from the TestDataSheet for the inflight options and scans$")
    public void iReadAndAssignDataFromTheTestDataSheetForTheInflightOptionsAndScans() throws IOException {
        HashMap<String,String>getMap= new HashMap<String,String>();
        File src=new File("InflightScan.xlsx");
        FileInputStream fis=new FileInputStream(src);
        XSSFWorkbook srcBook= new XSSFWorkbook(fis);
        XSSFSheet sourceSheet = srcBook.getSheetAt(0);

        XSSFSheet ScanSheet=srcBook.getSheetAt(1);
        XSSFRow FirstRow_scan =ScanSheet.getRow(0);

        XSSFSheet DeliveryChangeSheet=srcBook.getSheetAt(2);

        XSSFRow sourceRow = null;
        DataFormatter formatter = new DataFormatter();
        XSSFRow FirstRow =sourceSheet.getRow(0);
        int rowNum=0;
        DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MM/d/yy");
        for(int i=0;i<FirstRow_scan.getLastCellNum();i++){
            System.out.println("Date Value "+formatter.formatCellValue(FirstRow_scan.getCell(i)) + " equals "+ZonedDateTime.now().format(DATE));
            if(formatter.formatCellValue(FirstRow_scan.getCell(i)).equals(ZonedDateTime.now().format(DATE))){
                rowNum=i;
                System.out.println("RowNum "+rowNum);
                break;
            }
        }
        int rowCount_scan = ScanSheet.getLastRowNum();
        int rowCount_deliveryChange = DeliveryChangeSheet.getLastRowNum();
        for(int i=1;i<=sourceSheet.getLastRowNum();i++) {
            for(int j=0;j<FirstRow.getLastCellNum();j++){
                sourceRow = sourceSheet.getRow(i);
                getMap.put(formatter.formatCellValue(FirstRow.getCell(j)),formatter.formatCellValue(sourceRow.getCell(j)));
            }
            if(getMap.get("ScanType")!=null){
                System.out.println("rownumber : "+rowCount_scan);
                Row row = ScanSheet.createRow(++rowCount_scan);
                int columnCount = 0;
                Object Barcode = getMap.get("BARCODE");
                Object Scantype=getMap.get("ScanType");
                Cell barcode=row.createCell(columnCount);
                barcode.setCellValue((String)Barcode);
                Cell cell = row.createCell(rowNum);
                cell.setCellValue((String)Scantype);
            }
            System.out.println("getMap "+getMap);
            if(getMap.get("InflightOptions")!=null) {
                Row row = DeliveryChangeSheet.createRow(++rowCount_deliveryChange);
                int columnCount = 0;

                Object Scantype=getMap.get("InflightOptions");
                Cell cell = row.createCell(columnCount);
                cell.setCellValue((String)Scantype);

                Object uid = getMap.get("UID");
                Cell uid_cell=row.createCell(++columnCount);
                uid_cell.setCellValue((String)uid);

                Object Barcode = getMap.get("BARCODE");
                Cell barcode=row.createCell(++columnCount);
                barcode.setCellValue((String)Barcode);

                Object postcode = getMap.get("DESTINATIONPO");
                Cell postcode_cell=row.createCell(++columnCount);
                postcode_cell.setCellValue((String)postcode);

                Cell ActionDate_cell=row.createCell(++columnCount);
                ActionDate_cell.setCellValue((String)ZonedDateTime.now().format(DATE));

                Object InflightDetails = getMap.get("InflightDetails");
                Cell InflightDetails_cell=row.createCell(++columnCount);
                InflightDetails_cell.setCellValue((String)InflightDetails);

            }
        }

        fis.close();
        FileOutputStream outputStream = new FileOutputStream("InflightScan.xlsx");
        srcBook.write(outputStream);
        srcBook.close();
        outputStream.close();
    }

    @And("^I process the preadvice for the barcode in the Inflight data sheet$")
    public void iProcessThePreadviceForTheBarcodeInTheInflightDataSheet() throws IOException, InterruptedException {
        Boolean isPreadviceFileProcessed=readAndProcess("InflightScan.xlsx");
    }

    @Given("^I read the barcode and process the Scans from inflight data sheet$")
    public void iReadTheBarcodeAndProcessTheScansFromInflightDataSheet() throws IOException, InterruptedException {
        processScansfromSheet("InflightScan.xlsx");
    }

    @Given("^I read the barcode and process the Inflight options from inflight data sheet$")
    public void iReadTheBarcodeAndProcessTheInflightOptionsFromInflightDataSheet() throws IOException {
        HashMap<String,String>getMap= new HashMap<String,String>();
        File src=new File("InflightScan.xlsx");
        FileInputStream fis=new FileInputStream(src);
        XSSFWorkbook srcBook= new XSSFWorkbook(fis);
        XSSFSheet DeliveryChangeSheet=srcBook.getSheetAt(2);
        XSSFRow sourceRow = null;
        DataFormatter formatter = new DataFormatter();
        XSSFRow FirstRow =DeliveryChangeSheet.getRow(0);
        int rowNum=0;
        DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MM/d/yy");
        for(int i=0;i<FirstRow.getLastCellNum();i++){
            System.out.println("Date Value "+formatter.formatCellValue(FirstRow.getCell(i)) + " equals "+ZonedDateTime.now().format(DATE));
            if(formatter.formatCellValue(FirstRow.getCell(i)).equals(ZonedDateTime.now().format(DATE))){
                rowNum=i;
                System.out.println("RowNum "+rowNum);
                break;
            }
        }
        for(int i=1;i<=DeliveryChangeSheet.getLastRowNum();i++) {
            for (int j = 0; j < FirstRow.getLastCellNum(); j++) {
                sourceRow = DeliveryChangeSheet.getRow(i);
                getMap.put(formatter.formatCellValue(FirstRow.getCell(j)), formatter.formatCellValue(sourceRow.getCell(j)));
            }
        }
    }

    @And("^I validate the event generation for the barcode in TAPI$")
    public void iValidateTheEventGenerationForTheBarcodeInTAPI(Map<String, String> responseFields) throws IOException, ParseException {
        response = given().proxy("10.223.0.50",8080).headers("x-ibm-client-id", "11673592-68c4-413b-bdec-a84b2bfe27f3", "x-ibm-client-secret","pK8xI3aY1yS6uS0uS7oG1pW8vT5iB7iI4nV3mL4nK3cA6rT7wA","Accept", "application/json").when().get("https://test.api.royalmail.net/mailpieces/v2/"+BARCODE+"/events");
        json = response.then().statusCode(200);
        for (Map.Entry<String, String> field : responseFields.entrySet()) {
            ArrayList<Map<String, ?>> jsonAsArrayList = json.extract()
                    .jsonPath().get(field.getKey());
            Optional<Map<String, ?>> filtered = jsonAsArrayList.stream()
                    .filter(m -> m.get("eventCode").equals(field.getValue()))
                    .findFirst();
            updateJsonFile(BARCODE, Event);
            Assert.assertTrue("Event generation is failed in TAPI", filtered.isPresent());
        }
    }


    public Boolean ValidateBarcode(String BARCODE){
        try {
            RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + BARCODE + "/details";
            RequestSpecification httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
            Response response = httpRequest.get();
            int statusCode = response.getStatusCode();
            System.out.println("status code "+statusCode+RestAssured.baseURI);
            return statusCode == 404;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private Boolean ValidateUID(String UID) {
        try {
            RestAssured.baseURI = "http://psmsg-sit.rmgn.royalmailgroup.net/mailpieces/" + UID + "/details";
            RequestSpecification httpRequest = RestAssured.given().headers("X-RMG-Client-ID", "UAT", "Content-Type", "application/x-www-form-urlencoded");
            Response response = httpRequest.get();
            int statusCode = response.getStatusCode();
            return statusCode == 404;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Given("^I test the reporting for the Heartbeat$")
    public void iTestTheReportingForTheHeartbeat() {
        getReportName();
    }

    @And("^I open Redland site in the browser$")
    public void iOpenRedlandSiteInTheBrowser() {
          seleniumTests.setup();
    }

    @When("^I Input the barcode from the json file in to the Redland$")
    public void iInputTheBarcodeFromTheJsonFileInToTheRedland() throws InterruptedException {
         seleniumTests.inputBarcode();
    }

   @Then("^I validate the barcode details in the Redland reports for \"([^\"]*)\"$")
    public void iValidateTheBarcodeDetailsInTheRedlandReportsFor(String Scan) throws Throwable {
        seleniumTests.validateBarcode(Scan);
    }
}
