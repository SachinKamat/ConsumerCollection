package com.royalmail.StepDefinition;

import com.royalmail.Helpers.PageInstance;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.wink.json4j.JSONObject;
import org.apache.wink.json4j.OrderedJSONObject;
import org.json.simple.parser.ParseException;

import java.util.Map;

import static com.royalmail.Helpers.FileManipulation.*;
import static com.royalmail.Helpers.FileManipulation.readExcel;
import static org.hamcrest.Matchers.equalTo;

public class DeliveryChangeOptionsStepdefs extends PageInstance {
    private Response response;
    private ValidatableResponse json;
    private RequestSpecification request;

    @Before()
    public void beforeScenario(Scenario scenario) {
        PageInstance.scenario =scenario;
    }
    @Given("^\"([^\"]*)\" is processed with the \"([^\"]*)\"$")
    public void isProcessedWithThe(String Barcode, String PostCode) throws Throwable {
        request = RestAssured.given().proxy("10.223.0.50",8080).headers("Origin","*.royalmail.com","X-IBM-Client-Id","11673592-68c4-413b-bdec-a84b2bfe27f3","X-IBM-Client-Secret","pK8xI3aY1yS6uS0uS7oG1pW8vT5iB7iI4nV3mL4nK3cA6rT7wA","Content-Type","application/json");
    }

    @And("^response includes the following$")
    public void responseIncludesTheFollowing(Map<String,String> responseFields) {
        for (Map.Entry<String, String> field : responseFields.entrySet()) {
           if(StringUtils.isNumeric(field.getValue())){
                json.body(field.getKey(), equalTo(Integer.parseInt(field.getValue())));
            }
            else{
                json.body(field.getKey(), equalTo(field.getValue()));
            }
        }
    }

    @Then("^the status code is (\\d+)$")
    public void theStatusCodeIs(int statusCode) {
        json = response.then().statusCode(statusCode);
    }


    @When("^a user retrieves the options for the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void aUserRetrievesTheOptionsForTheAnd(String Barcode, String PostCode) throws Throwable {
        response = request.when().get("https://test.api.royalmail.net/delivery-change/v1/mailpieces/"+Barcode+"/options?postCode="+PostCode);
    }


    @When("^a user performs SET Delivery change option with excel row\"([^\"]*)\" dataset$")
    public void aUserPerformsSETDeliveryChangeOptionWithExcelRowDataset(int indexOfExcel) throws Throwable {

        DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        JSONObject safeplacedetails = new OrderedJSONObject();
        Map<String,String> responseFields =readExcel(indexOfExcel);
        System.out.println(" responseFields "+responseFields);
        safeplacedetails.put("locationCode","20006");
        safeplacedetails.put("locationText","Shed");
        safeplacedetails.put("additionalDetails","Next to Garage");


        JSONObject address = new OrderedJSONObject();
        address.put("buildingName","Building 1");
        address.put("buildingNumber","1");
        address.put("addressLine1","addressLine1");
        address.put("addressLine2","addressLine2");
        address.put("addressLine3","addressLine3");
        address.put("addressLine4","addressLine4");
        address.put("addressLine5","addressLine5");
        address.put("stateOrProvince","stateOrProvince");
        address.put("postTown","Harrow");
        address.put("county","Middlesex");
        address.put("postcode",responseFields.get("PostCode"));
        address.put("country","United Kingdom");


        JSONObject optionDetails = new OrderedJSONObject();
        optionDetails.put("requestedDateTime", ZonedDateTime.now().format(FORMATTER));
        optionDetails.put("requestedActionDateTime",responseFields.get("ActionDate")+"T11:04:01");
        optionDetails.put("optionType",responseFields.get("Option"));
        optionDetails.put("updatedNotificationEmail","sapna.negi@royalmail.com");


        JSONObject optionRequest = new OrderedJSONObject();
        optionRequest.put("requestingChannel","EBIZ");
        optionRequest.put("optionDetails",optionDetails);
        optionRequest.put("address",address);
        optionRequest.put("safePlaceDetails",safeplacedetails);


        JSONObject jsonObjectToPost = new OrderedJSONObject();
        jsonObjectToPost.put("mailPieceId",responseFields.get("Barcode"));
        jsonObjectToPost.put("destinationPostCode",responseFields.get("PostCode"));
        jsonObjectToPost.put("optionRequest",optionRequest);


        JSONObject Final_jsonObjectToPost = new OrderedJSONObject();
        Final_jsonObjectToPost.put("mailPieces",jsonObjectToPost);

        response = request.body(Final_jsonObjectToPost.toString()).when().post("https://test.api.royalmail.net/delivery-change/v1/mailpieces/"+responseFields.get("1DBarcode")+"/options?postCode="+responseFields.get("PostCode"));
    }

    @When("^I perform the Acceptance Scan on the Barcode$")
    public void iPerformTheAcceptanceScanOnTheBarcode() throws IOException, ParseException, InterruptedException {
        Thread.sleep(10000);
        Boolean isScanPerformed =false;
        Event=getEventFromJSON();
        System.out.println("Event "+Event);
        if(!Event.equalsIgnoreCase("EVDAC")) {
            if (Event.equalsIgnoreCase("EVAIP") || Event.equalsIgnoreCase("")) {
                System.out.println("Performing Acceptance scan" + Event);
                Event = "EVDAC";
            }
            isScanPerformed = PerformScan(Event);
        }else {
            System.out.println("Acceptance scan already performed "+Event);
        }
    }


}
